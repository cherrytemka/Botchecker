#!/usr/bin/env python3
"""Telegram bot that checks saved Bybit P2P merchants on USDT/USD and USDT/TJS."""

from __future__ import annotations

import getpass
import html
import json
import os
import re
import secrets
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen


BASE_DIR = Path(__file__).resolve().parent
BACKUP_PATH = BASE_DIR / "merchant-catcher-backup.json"
CONFIG_PATH = BASE_DIR / "bot_config.json"
DATA_PATH = BASE_DIR / "bot_data.json"

BYBIT_URL = "https://www.bybit.com/x-api/fiat/otc/item/online"
TELEGRAM_URL = "https://api.telegram.org/bot{token}/{method}"

MARKETS = {
    "USDT/USD": {"tokenId": "USDT", "currencyId": "USD"},
    "USDT/TJS": {"tokenId": "USDT", "currencyId": "TJS"},
}
SIDES = ("0", "1")
PAGE_SIZE = 100
MAX_PAGES = 10
REQUEST_DELAY_SECONDS = 0.45
CACHE_TTL_SECONDS = 25
PROFILE_ID_RE = re.compile(r"^s[0-9a-f]{32}$", re.IGNORECASE)
UID_RE = re.compile(r"^\d{4,15}$")
PROFILE_PATH_RE = re.compile(r"(?:^|/)p2p/profile/(s[0-9a-f]{32})(?:/|$)", re.IGNORECASE)
BYBIT_HOST_RE = re.compile(r"(?:^|\.)bybit\.(?:com|kz|eu|nl|tr|ae|id)$", re.IGNORECASE)


class BotError(RuntimeError):
    pass


def normalized_name(value: Any) -> str:
    if value is None or isinstance(value, (dict, list)):
        return ""
    name = re.sub(r"\s+", " ", str(value)).strip()
    if name.lower() in {"", "null", "undefined", "none", "unknown", "n/a"}:
        return ""
    return name


def load_merchants(path: Path = BACKUP_PATH) -> list[dict[str, str]]:
    """Read the extension backup; only profile IDs and display names are needed."""
    try:
        with path.open("r", encoding="utf-8") as file:
            backup = json.load(file)
    except FileNotFoundError as exc:
        raise BotError(f"Не найден файл списка мерчантов: {path.name}") from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise BotError(f"Не удалось прочитать JSON бэкап: {exc}") from exc

    if not isinstance(backup, dict) or backup.get("format") != "merchant-catcher-backup":
        raise BotError("Файл не похож на резервную копию «Ловца мерчантов».")

    nickname_cache = backup.get("profileNicknameCache") or {}
    if not isinstance(nickname_cache, dict):
        nickname_cache = {}

    merchants: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in backup.get("merchants", []):
        if not isinstance(item, dict):
            continue
        profile_id = str(item.get("profileId") or "").lower()
        uid = str(item.get("uid") or "")
        if not PROFILE_ID_RE.fullmatch(profile_id) and not UID_RE.fullmatch(uid):
            continue
        key = profile_id or f"uid:{uid}"
        if key in seen:
            continue
        seen.add(key)
        nickname = (
            normalized_name(item.get("nickname"))
            or normalized_name(item.get("nickName"))
            or normalized_name(item.get("label"))
            or normalized_name(nickname_cache.get(profile_id))
        )
        source = str(item.get("source") or "").strip()
        if profile_id:
            source = f"https://www.bybit.com/ru-RU/p2p/profile/{profile_id}"
        merchants.append({
            "profileId": profile_id,
            "uid": uid,
            "nickname": nickname or (f"Мерчант {profile_id[:9]}…" if profile_id else f"UID {uid}"),
            "source": source,
        })
    return merchants


def load_bot_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        value = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BotError(f"Не удалось прочитать {CONFIG_PATH.name}: {exc}") from exc
    return value if isinstance(value, dict) else {}


def save_bot_config(config: dict[str, Any]) -> None:
    temporary = CONFIG_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(CONFIG_PATH)
    try:
        CONFIG_PATH.chmod(0o600)
    except OSError:
        pass


def load_bot_data() -> dict[str, Any]:
    default = {"admin_added": {}, "hidden_global": [], "user_merchants": {}}
    if not DATA_PATH.exists():
        return default
    try:
        value = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BotError(f"Не удалось прочитать базу бота {DATA_PATH.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise BotError(f"Файл {DATA_PATH.name} повреждён: ожидался JSON-объект.")
    for key, default_value in default.items():
        if not isinstance(value.get(key), type(default_value)):
            value[key] = default_value
    return value


def save_bot_data(data: dict[str, Any]) -> None:
    temporary = DATA_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(DATA_PATH)
    try:
        DATA_PATH.chmod(0o600)
    except OSError:
        pass


def parse_profile_link(text: str) -> str:
    value = str(text or "").strip().strip("<>\"'").rstrip(".,;!?)]}>")
    if not value:
        raise BotError("Пришли ссылку на P2P-профиль Bybit.")
    if not re.match(r"^https?://", value, re.IGNORECASE):
        value = "https://" + value
    parsed = urlparse(value)
    hostname = (parsed.hostname or "").lower()
    if not BYBIT_HOST_RE.search(hostname):
        raise BotError("Принимаю только ссылки Bybit вида https://www.bybit.com/ru-RU/p2p/profile/s…")
    match = PROFILE_PATH_RE.search(parsed.path)
    if not match:
        raise BotError("Не нашёл код профиля в ссылке. Нужна страница /p2p/profile/s…")
    return match.group(1).lower()


def merchant_from_profile_id(profile_id: str, nickname: str = "") -> dict[str, str]:
    profile_id = str(profile_id or "").lower()
    if not PROFILE_ID_RE.fullmatch(profile_id):
        raise BotError("Некорректный код профиля Bybit.")
    return {
        "profileId": profile_id,
        "uid": "",
        "nickname": normalized_name(nickname) or f"Мерчант {profile_id[:9]}…",
        "source": f"https://www.bybit.com/ru-RU/p2p/profile/{profile_id}",
    }


def merchant_key(merchant: dict[str, Any]) -> str:
    profile_id = str(merchant.get("profileId") or "").lower()
    if PROFILE_ID_RE.fullmatch(profile_id):
        return profile_id
    uid = str(merchant.get("uid") or "")
    return f"uid:{uid}" if UID_RE.fullmatch(uid) else ""


def load_global_merchants() -> list[dict[str, Any]]:
    data = load_bot_data()
    hidden = {str(value).lower() for value in data["hidden_global"]}
    merged: dict[str, dict[str, Any]] = {}
    for merchant in load_merchants():
        key = merchant_key(merchant)
        if key and key not in hidden:
            merged[key] = {**merchant, "adminAdded": True}
    for profile_id, item in data["admin_added"].items():
        profile_id = str(profile_id).lower()
        if not PROFILE_ID_RE.fullmatch(profile_id) or profile_id in hidden or not isinstance(item, dict):
            continue
        merchant = merchant_from_profile_id(profile_id, item.get("nickname", ""))
        merged[profile_id] = {**merchant, "adminAdded": True}
    return list(merged.values())


def load_user_merchants(user_id: int | str) -> list[dict[str, Any]]:
    data = load_bot_data()
    store = data["user_merchants"].get(str(user_id), {})
    if not isinstance(store, dict):
        return []
    result = []
    for profile_id, item in store.items():
        profile_id = str(profile_id).lower()
        if PROFILE_ID_RE.fullmatch(profile_id) and isinstance(item, dict):
            result.append(merchant_from_profile_id(profile_id, item.get("nickname", "")))
    return result


def merchants_for_user(user_id: int | str) -> list[dict[str, Any]]:
    combined: dict[str, dict[str, Any]] = {}
    for merchant in load_global_merchants():
        key = merchant_key(merchant)
        if key:
            combined[key] = merchant
    for merchant in load_user_merchants(user_id):
        key = merchant_key(merchant)
        if key and key not in combined:
            combined[key] = {**merchant, "adminAdded": False}
    return list(combined.values())


def profile_url_for_market(merchant: dict[str, str], market: str) -> str:
    if market not in MARKETS:
        raise BotError("Для этой пары стакан не настроен.")
    base = merchant.get("source") or ""
    profile_id = merchant.get("profileId") or ""
    if not base and PROFILE_ID_RE.fullmatch(profile_id):
        base = f"https://www.bybit.com/ru-RU/p2p/profile/{profile_id}"
    if not base:
        return "https://www.bybit.com/ru-RU/p2p/"
    parsed = urlparse(base)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query.update(MARKETS[market])
    return urlunparse(parsed._replace(query=urlencode(query)))


def is_online(value: Any) -> bool | None:
    if value is True or value == 1 or (isinstance(value, str) and value.lower() == "true"):
        return True
    if value is False or value == 0 or (isinstance(value, str) and value.lower() == "false"):
        return False
    if isinstance(value, str) and value in {"1", "0"}:
        return value == "1"
    return None


def item_matches_merchant(item: dict[str, Any], merchant: dict[str, str]) -> bool:
    profile_id = merchant.get("profileId", "").lower()
    item_profile_id = str(item.get("userMaskId") or "").lower()
    if profile_id and item_profile_id == profile_id:
        return True
    uid = merchant.get("uid", "")
    if not UID_RE.fullmatch(uid):
        return False
    ids = (item.get("makerUserId"), item.get("userId"), item.get("accountId"))
    return uid in {str(value) for value in ids if value not in (None, "", "0", 0)}


def extract_ad_nickname(item: dict[str, Any]) -> str:
    for key in ("nickName", "nickname", "nick_name", "userName", "username"):
        value = normalized_name(item.get(key))
        if value:
            return value
    for key in ("userInfo", "makerInfo", "merchantInfo", "profile", "user", "maker"):
        nested = item.get(key)
        if isinstance(nested, dict):
            value = extract_ad_nickname(nested)
            if value:
                return value
    return ""


def scan_market(
    merchants: list[dict[str, str]],
    market: str,
    get_ads: Callable[[dict[str, Any]], dict[str, Any]],
    *,
    max_pages: int = MAX_PAGES,
    page_size: int = PAGE_SIZE,
    request_delay: float = REQUEST_DELAY_SECONDS,
    sleep: Callable[[float], None] = time.sleep,
) -> tuple[list[dict[str, Any]], bool]:
    """Return merchants with at least one online ad in the selected market."""
    market_data = MARKETS.get(market)
    if not market_data:
        raise BotError("Выбери один из доступных стаканов: USDT/USD или USDT/TJS.")

    online: dict[str, dict[str, Any]] = {}
    all_pages_checked = True
    request_count = 0

    for side in SIDES:
        side_reached_end = False
        for page in range(1, max_pages + 1):
            if request_count and request_delay:
                sleep(request_delay)
            payload = {
                **market_data,
                "side": side,
                "page": str(page),
                "size": str(page_size),
                "userId": 0,
                "itemRegion": 1,
            }
            result = get_ads(payload)
            request_count += 1
            items = result.get("items") if isinstance(result, dict) else None
            items = items if isinstance(items, list) else []
            total_count = int(result.get("count") or 0) if isinstance(result, dict) else 0

            for item in items:
                if not isinstance(item, dict) or is_online(item.get("isOnline")) is not True:
                    continue
                for merchant in merchants:
                    if not item_matches_merchant(item, merchant):
                        continue
                    key = merchant_key(merchant)
                    entry = online.setdefault(key, {
                        **merchant,
                        "onlineAds": 0,
                        "buyFromMerchantAds": 0,
                        "sellToMerchantAds": 0,
                        "adIds": set(),
                    })
                    live_nickname = extract_ad_nickname(item)
                    if live_nickname:
                        entry["nickname"] = live_nickname
                    ad_id = str(item.get("id") or f"{side}:{item.get('price')}:{item.get('quantity')}:{item.get('userMaskId')}")
                    unique_ad_id = f"{side}:{ad_id}"
                    if unique_ad_id in entry["adIds"]:
                        continue
                    entry["adIds"].add(unique_ad_id)
                    entry["onlineAds"] += 1
                    if side == "1":
                        entry["buyFromMerchantAds"] += 1
                    else:
                        entry["sellToMerchantAds"] += 1

            consumed = page * page_size
            if len(items) < page_size or total_count == 0 or (total_count > 0 and consumed >= total_count):
                side_reached_end = True
                break
        if not side_reached_end:
            all_pages_checked = False

    ordered = []
    for merchant in merchants:
        key = merchant_key(merchant)
        if key in online:
            entry = online[key]
            entry.pop("adIds", None)
            ordered.append(entry)
    return ordered, all_pages_checked


class BybitClient:
    def get_ads(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = Request(
            BYBIT_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json, text/plain, */*",
                "Origin": "https://www.bybit.com",
                "Referer": "https://www.bybit.com/ru-RU/p2p/",
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=20) as response:
                raw = response.read()
        except HTTPError as exc:
            if exc.code == 403:
                raise BotError("Bybit временно отклонил запрос (HTTP 403). Попробуй позже или проверь доступность P2P в своей сети.") from exc
            if exc.code == 429:
                raise BotError("Bybit ограничил частоту запросов. Подожди немного и попробуй снова.") from exc
            raise BotError(f"Bybit вернул HTTP {exc.code}.") from exc
        except URLError as exc:
            raise BotError(f"Нет соединения с Bybit: {exc.reason}") from exc

        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BotError("Bybit вернул ответ, который бот не смог прочитать.") from exc
        code = data.get("ret_code", data.get("retCode"))
        if code is not None and str(code) != "0":
            message = data.get("ret_msg") or data.get("retMsg") or "неизвестная ошибка"
            raise BotError(f"Bybit API: {message}")
        result = data.get("result") or {}
        return result if isinstance(result, dict) else {}


class TelegramClient:
    def __init__(self, token: str):
        self.token = token

    def call(self, method: str, payload: dict[str, Any] | None = None, *, timeout: int = 30) -> Any:
        request = Request(
            TELEGRAM_URL.format(token=self.token, method=method),
            data=json.dumps(payload or {}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:300]
            raise BotError(f"Telegram API вернул HTTP {exc.code}: {detail}") from exc
        except (URLError, TimeoutError) as exc:
            reason = str(exc.reason) if isinstance(exc, URLError) else str(exc)
            if "CERTIFICATE_VERIFY_FAILED" in reason:
                raise BotError("Mac не доверяет HTTPS-сертификату Telegram. Start.command теперь выбирает Python из /Applications/Python 3.x; запусти для этой же версии Install Certificates.command. Если он пишет update complete, проверь запуск через другую сеть без VPN или HTTPS-фильтрации.") from exc
            raise BotError(f"Не удалось связаться с Telegram: {reason}") from exc
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BotError("Telegram вернул ответ, который бот не смог прочитать.") from exc
        if not data.get("ok"):
            raise BotError(f"Telegram API: {data.get('description') or 'ошибка запроса'}")
        return data.get("result")


def load_token() -> str:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    config = load_bot_config()
    if not token:
        token = str(config.get("token") or "").strip()
    if token:
        return token
    if not sys.stdin.isatty():
        raise BotError("Укажи TELEGRAM_BOT_TOKEN или запусти Start.command в Terminal для первой настройки.")

    print("Создай бота через @BotFather в Telegram и скопируй его токен.")
    token = getpass.getpass("Вставь токен бота (ввод скрыт): ").strip()
    if not token:
        raise BotError("Токен не введён.")
    config["token"] = token
    save_bot_config(config)
    return token


def ensure_admin_claim_code() -> str:
    """Create a local one-time secret so only the Mac owner can claim admin."""
    if os.environ.get("BOT_ADMIN_ID", "").strip():
        return ""
    config = load_bot_config()
    if str(config.get("admin_id") or "").strip():
        return ""
    code = str(config.get("admin_claim_code") or "").strip()
    if not code:
        code = secrets.token_urlsafe(18)
        config["admin_claim_code"] = code
        save_bot_config(config)
    return code


def configured_admin_id() -> str:
    return os.environ.get("BOT_ADMIN_ID", "").strip() or str(load_bot_config().get("admin_id") or "").strip()


def market_picker_keyboard() -> dict[str, Any]:
    return {"inline_keyboard": [
        [
            {"text": "🇺🇸 USDT / USD", "callback_data": "market:USDT/USD"},
            {"text": "🇹🇯 USDT / TJS", "callback_data": "market:USDT/TJS"},
        ],
        [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
    ]}


def main_keyboard(is_admin: bool = False) -> dict[str, Any]:
    rows = [
        [{"text": "🟢 Кто в сети", "callback_data": "choose_market"}],
        [
            {"text": "➕ Добавить отслежку", "callback_data": "personal:add"},
            {"text": "🗂 Мои отслежки", "callback_data": "personal:list"},
        ],
    ]
    if is_admin:
        rows.append([{"text": "👑 Админ-панель", "callback_data": "admin:home"}])
    return {"inline_keyboard": rows}


def results_keyboard(market: str) -> dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": f"🔄 Проверить снова · {market}", "callback_data": f"refresh:{market}"}],
        [
            {"text": "USDT / USD", "callback_data": "market:USDT/USD"},
            {"text": "USDT / TJS", "callback_data": "market:USDT/TJS"},
        ],
        [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
    ]}


def back_to_menu_keyboard(is_admin: bool = False) -> dict[str, Any]:
    return {"inline_keyboard": [[{"text": "⬅️ Главное меню", "callback_data": "menu"}]]}


def cancel_input_keyboard() -> dict[str, Any]:
    return {"inline_keyboard": [[{"text": "Отмена", "callback_data": "cancel_input"}]]}


def split_html_message(text: str, max_chars: int = 3500) -> list[str]:
    lines = text.splitlines()
    pages: list[str] = []
    current = ""
    for line in lines:
        candidate = f"{current}\n{line}" if current else line
        if current and len(candidate) > max_chars:
            pages.append(current)
            current = line
        else:
            current = candidate
    if current:
        pages.append(current)
    return pages or [""]


def format_results(market: str, merchants: list[dict[str, Any]], complete: bool) -> str:
    checked = datetime.now().astimezone().strftime("%H:%M:%S")
    lines = [f"<b>🟢 Онлайн мерчанты · {html.escape(market)}</b>", f"Проверено: {checked}", ""]
    if not merchants:
        lines.append("В этом стакане сейчас не найдено онлайн-объявлений от мерчантов из списка.")
    else:
        for index, merchant in enumerate(merchants, start=1):
            crown = "👑 " if merchant.get("adminAdded") else ""
            name = html.escape(crown + (merchant.get("nickname") or "Мерчант"))
            link = html.escape(profile_url_for_market(merchant, market), quote=True)
            lines.append(
                f'{index}. <a href="{link}">{name}</a> · онлайн-объявлений: {merchant["onlineAds"]} '
                f'(купить у: {merchant["buyFromMerchantAds"]}, продать: {merchant["sellToMerchantAds"]})'
            )
    if not complete:
        lines.extend(["", f"⚠️ Проверены только первые {MAX_PAGES} страниц каждого направления; список может быть неполным."])
    lines.extend(["", "Нажми кнопку ниже, чтобы обновить список."])
    return "\n".join(lines)


class MerchantBot:
    def __init__(self, token: str):
        self.telegram = TelegramClient(token)
        self.bybit = BybitClient()
        self.offset = 0
        self.cache: dict[str, tuple[float, list[dict[str, Any]], bool]] = {}
        self.pending_inputs: dict[str, str] = {}

    @staticmethod
    def is_admin(user_id: int | str) -> bool:
        return bool(configured_admin_id()) and str(user_id) == configured_admin_id()

    @staticmethod
    def _command(text: str) -> str:
        if not text.startswith("/"):
            return ""
        return text.split(maxsplit=1)[0].split("@", 1)[0].lower()

    def _answer_callback(self, callback_id: str, message: str = "") -> None:
        if not callback_id:
            return
        payload: dict[str, Any] = {"callback_query_id": callback_id}
        if message:
            payload["text"] = message
            payload["show_alert"] = True
        self.telegram.call("answerCallbackQuery", payload)

    def send_message(self, chat_id: int, text: str, keyboard: dict[str, Any] | None = None) -> None:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        if keyboard:
            payload["reply_markup"] = keyboard
        self.telegram.call("sendMessage", payload)

    def edit_message(
        self, chat_id: int, message_id: int, text: str, keyboard: dict[str, Any] | None = None
    ) -> None:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        if keyboard:
            payload["reply_markup"] = keyboard
        self.telegram.call("editMessageText", payload)

    def send_home(self, chat_id: int, user_id: int | str) -> None:
        self.send_message(chat_id, "<b>Ловец мерчантов</b>\nВыбери действие:", main_keyboard(self.is_admin(user_id)))

    def scan(self, user_id: int | str, market: str, *, force: bool = False) -> tuple[list[dict[str, Any]], bool]:
        if market not in MARKETS:
            raise BotError("Доступны только USDT/USD и USDT/TJS.")
        cache_key = f"{user_id}:{market}"
        cached = self.cache.get(cache_key)
        if not force and cached and time.monotonic() - cached[0] < CACHE_TTL_SECONDS:
            return cached[1], cached[2]
        merchants = merchants_for_user(user_id)
        if not merchants:
            raise BotError("В общем списке пока нет мерчантов. Добавь свою отслежку по ссылке.")
        result, complete = scan_market(merchants, market, self.bybit.get_ads)
        self.cache[cache_key] = (time.monotonic(), result, complete)
        return result, complete

    def _invalidate_cache(self, user_id: int | str | None = None) -> None:
        if user_id is None:
            self.cache.clear()
            return
        prefix = f"{user_id}:"
        for key in list(self.cache):
            if key.startswith(prefix):
                self.cache.pop(key, None)

    def _global_by_key(self, key: str) -> dict[str, Any] | None:
        return next((item for item in load_global_merchants() if merchant_key(item) == key), None)

    def _add_user_merchant(self, user_id: int | str, profile_id: str) -> str:
        if any(merchant_key(item) == profile_id for item in load_global_merchants()):
            return "Этот мерчант уже есть в общем списке и доступен всем."
        data = load_bot_data()
        users = data["user_merchants"]
        user_store = users.setdefault(str(user_id), {})
        if profile_id in user_store:
            return "Эта ссылка уже есть в твоих отслежках."
        merchant = merchant_from_profile_id(profile_id)
        user_store[profile_id] = {"nickname": merchant["nickname"]}
        save_bot_data(data)
        self._invalidate_cache(user_id)
        return f"Добавил в твой личный список: <a href=\"{html.escape(merchant['source'], quote=True)}\">{html.escape(merchant['nickname'])}</a>. Другие пользователи эту отслежку не увидят."

    def _add_global_merchant(self, profile_id: str) -> str:
        visible = load_global_merchants()
        if any(merchant_key(item) == profile_id for item in visible):
            return "Этот мерчант уже находится в общем списке."
        data = load_bot_data()
        hidden = {str(value).lower() for value in data["hidden_global"]}
        base = load_merchants()
        is_in_backup = any(merchant_key(item) == profile_id for item in base)
        if profile_id in hidden:
            data["hidden_global"] = [value for value in data["hidden_global"] if str(value).lower() != profile_id]
        if not is_in_backup:
            data["admin_added"][profile_id] = {"nickname": merchant_from_profile_id(profile_id)["nickname"]}
        save_bot_data(data)
        self._invalidate_cache()
        return f"Добавил в общий список с короной: <a href=\"{html.escape(merchant_from_profile_id(profile_id)['source'], quote=True)}\">{html.escape(merchant_from_profile_id(profile_id)['nickname'])}</a>."

    def _delete_global_merchant(self, key: str) -> None:
        data = load_bot_data()
        base_keys = {merchant_key(item) for item in load_merchants()}
        if key in base_keys and key not in data["hidden_global"]:
            data["hidden_global"].append(key)
        if key in data["admin_added"]:
            data["admin_added"].pop(key, None)
        save_bot_data(data)
        self._invalidate_cache()

    def _delete_user_merchant(self, user_id: int | str, profile_id: str) -> None:
        data = load_bot_data()
        store = data["user_merchants"].get(str(user_id), {})
        if isinstance(store, dict):
            store.pop(profile_id, None)
            if not store:
                data["user_merchants"].pop(str(user_id), None)
        save_bot_data(data)
        self._invalidate_cache(user_id)

    def _render_admin_home(self, chat_id: int, message_id: int) -> None:
        keyboard = {"inline_keyboard": [
            [{"text": "➕ Добавить общего мерчанта", "callback_data": "admin:add"}],
            [{"text": "🗑 Удалить общего мерчанта", "callback_data": "admin:delete"}],
            [{"text": "📋 Показать общий список", "callback_data": "admin:list"}],
            [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
        ]}
        self.edit_message(chat_id, message_id, "<b>👑 Админ-панель</b>\nИзменения общего списка увидят все пользователи.", keyboard)

    def _render_personal_list(self, chat_id: int, message_id: int, user_id: int | str) -> None:
        merchants = load_user_merchants(user_id)
        if not merchants:
            keyboard = {"inline_keyboard": [
                [{"text": "➕ Добавить отслежку", "callback_data": "personal:add"}],
                [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
            ]}
            self.edit_message(chat_id, message_id, "<b>Твои отслежки</b>\nЛичный список пока пуст.", keyboard)
            return
        rows = []
        lines = ["<b>Твои личные отслежки</b>", "Нажми на мерчанта, чтобы удалить его:"]
        for item in merchants:
            key = merchant_key(item)
            rows.append([{"text": f"🗑 {item['nickname'][:32]}", "callback_data": f"personal:pick:{key}"}])
            link = html.escape(item["source"], quote=True)
            lines.append(f'<a href="{link}">{html.escape(item["nickname"])}</a>')
        rows.extend([
            [{"text": "➕ Добавить отслежку", "callback_data": "personal:add"}],
            [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
        ])
        pages = split_html_message("\n".join(lines))
        self.edit_message(chat_id, message_id, pages[0], {"inline_keyboard": rows})
        for page in pages[1:]:
            self.send_message(chat_id, page)

    def _render_global_delete_list(self, chat_id: int, message_id: int) -> None:
        merchants = load_global_merchants()
        if not merchants:
            self.edit_message(chat_id, message_id, "Общий список пуст.", back_to_menu_keyboard(True))
            return
        lines = ["<b>Выбери мерчанта для удаления из общего списка:</b>"]
        buttons = []
        for item in merchants:
            key = merchant_key(item)
            crown = "👑 " if item.get("adminAdded") else ""
            button = {"text": f"{crown}{item['nickname'][:30]}", "callback_data": f"admin:pick:{key}"}
            buttons.append(button)
            link = html.escape(profile_url_for_market(item, "USDT/USD"), quote=True)
            lines.append(f'<a href="{link}">{html.escape(crown + item["nickname"])}</a>')
        rows = [buttons[index:index + 2] for index in range(0, len(buttons), 2)]
        rows.append([{"text": "⬅️ В админ-панель", "callback_data": "admin:home"}])
        pages = split_html_message("\n".join(lines))
        self.edit_message(chat_id, message_id, pages[0], {"inline_keyboard": rows})
        for page in pages[1:]:
            self.send_message(chat_id, page)

    def _render_global_list(self, chat_id: int, message_id: int) -> None:
        merchants = load_global_merchants()
        lines = ["<b>👑 Общий список мерчантов</b>"]
        if not merchants:
            lines.append("Список пуст.")
        for item in merchants:
            link = html.escape(profile_url_for_market(item, "USDT/USD"), quote=True)
            lines.append(f'<a href="{link}">👑 {html.escape(item["nickname"])}</a>')
        pages = split_html_message("\n".join(lines))
        self.edit_message(chat_id, message_id, pages[0], back_to_menu_keyboard(True))
        for page in pages[1:]:
            self.send_message(chat_id, page)

    def _begin_input(self, chat_id: int, message_id: int, user_id: int | str, scope: str) -> None:
        self.pending_inputs[str(user_id)] = scope
        if scope == "admin":
            text = "Пришли ссылку на Bybit P2P-профиль. Он попадёт в общий список и будет отмечен 👑."
        else:
            text = "Пришли ссылку на Bybit P2P-профиль. Он будет виден и проверяться только в твоём личном списке."
        self.edit_message(chat_id, message_id, text, cancel_input_keyboard())

    def _handle_link_input(self, chat_id: int, user_id: int | str, text: str, scope: str) -> None:
        try:
            profile_id = parse_profile_link(text)
            if scope == "admin":
                result = self._add_global_merchant(profile_id)
                self.pending_inputs.pop(str(user_id), None)
                self.send_message(chat_id, result, {"inline_keyboard": [[{"text": "👑 Админ-панель", "callback_data": "admin:home"}]]})
            else:
                result = self._add_user_merchant(user_id, profile_id)
                if "уже есть" not in result.lower() and "уже находится" not in result.lower():
                    self.pending_inputs.pop(str(user_id), None)
                self.send_message(chat_id, result, main_keyboard(self.is_admin(user_id)))
        except BotError as exc:
            self.send_message(chat_id, f"{html.escape(str(exc))}\nПопробуй ещё раз или нажми «Отмена».", cancel_input_keyboard())

    def handle_message(self, message: dict[str, Any]) -> None:
        chat = message.get("chat") or {}
        chat_id = chat.get("id")
        if not chat_id:
            return
        text = str(message.get("text") or "").strip()
        user_id = (message.get("from") or {}).get("id")
        if not user_id:
            return
        command = self._command(text)

        if command == "/claimadmin":
            if chat.get("type") != "private":
                self.send_message(chat_id, "Первичную настройку админа выполни в личном чате с ботом.")
                return
            config = load_bot_config()
            if configured_admin_id():
                self.send_message(chat_id, "Администратор уже назначен.")
                return
            code = str(config.get("admin_claim_code") or "")
            supplied = text.split(maxsplit=1)[1].strip() if len(text.split(maxsplit=1)) == 2 else ""
            if not code or not supplied or not secrets.compare_digest(supplied, code):
                self.send_message(chat_id, "Код не подошёл. Сверь его с кодом первичной настройки в Terminal на компьютере.")
                return
            config["admin_id"] = str(user_id)
            config.pop("admin_claim_code", None)
            save_bot_config(config)
            self.send_message(chat_id, "Готово, ты администратор. Кнопка 👑 Админ-панель появилась в меню.", main_keyboard(True))
            print(f"Назначен администратор Telegram ID {user_id}.")
            return

        if chat.get("type") != "private":
            self.send_message(chat_id, "Для личных отслежек напиши боту в личный чат.")
            return

        if not configured_admin_id():
            self.send_message(chat_id, "Бот ещё не привязан к владельцу. Выполни первичную настройку командой /claimadmin и кодом из Terminal.")
            return

        if command == "/cancel":
            self.pending_inputs.pop(str(user_id), None)
            self.send_home(chat_id, user_id)
            return

        pending_scope = self.pending_inputs.get(str(user_id))
        if pending_scope and not command:
            self._handle_link_input(chat_id, user_id, text, pending_scope)
            return

        if command in ("/start", "/menu"):
            self.send_home(chat_id, user_id)
        elif command == "/help":
            self.send_message(chat_id, "Выбери «Кто в сети» и стакан USDT/USD или USDT/TJS. Общие мерчанты доступны всем; свои ссылки добавляются отдельно и видны только тебе.", main_keyboard(self.is_admin(user_id)))
        elif command == "/admin":
            if self.is_admin(user_id):
                keyboard = {"inline_keyboard": [[{"text": "Открыть админ-панель", "callback_data": "admin:home"}]]}
                self.send_message(chat_id, "👑 Админ-панель", keyboard)
            else:
                self.send_message(chat_id, "Нет доступа к админ-панели.")
        elif command == "/my":
            self._send_personal_list(chat_id, user_id)
        elif command == "/add":
            self.pending_inputs[str(user_id)] = "personal"
            self.send_message(chat_id, "Пришли ссылку на Bybit P2P-профиль. Он будет только в твоём личном списке.", cancel_input_keyboard())
        else:
            self.send_message(chat_id, "Используй кнопки меню. Чтобы добавить личного мерчанта, нажми «Добавить отслежку».", main_keyboard(self.is_admin(user_id)))

    def _send_personal_list(self, chat_id: int, user_id: int | str) -> None:
        merchants = load_user_merchants(user_id)
        if not merchants:
            self.send_message(chat_id, "<b>Твои личные отслежки</b>\nСписок пока пуст.", {"inline_keyboard": [
                [{"text": "➕ Добавить отслежку", "callback_data": "personal:add"}],
                [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
            ]})
            return
        lines = ["<b>Твои личные отслежки</b>"]
        rows = []
        for item in merchants:
            key = merchant_key(item)
            link = html.escape(item["source"], quote=True)
            lines.append(f'<a href="{link}">{html.escape(item["nickname"])}</a>')
            rows.append([{"text": f"🗑 {item['nickname'][:32]}", "callback_data": f"personal:pick:{key}"}])
        rows.extend([
            [{"text": "➕ Добавить отслежку", "callback_data": "personal:add"}],
            [{"text": "⬅️ Главное меню", "callback_data": "menu"}],
        ])
        pages = split_html_message("\n".join(lines))
        self.send_message(chat_id, pages[0], {"inline_keyboard": rows})
        for page in pages[1:]:
            self.send_message(chat_id, page)

    def handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = callback.get("id")
        data = str(callback.get("data") or "")
        message = callback.get("message") or {}
        chat = message.get("chat") or {}
        chat_id = chat.get("id")
        message_id = message.get("message_id")
        user_id = (callback.get("from") or {}).get("id")
        if not chat_id or not message_id:
            return
        if chat.get("type") != "private":
            self._answer_callback(callback_id, "Открой личный чат с ботом.")
            return
        if not user_id:
            self._answer_callback(callback_id, "Не получилось определить пользователя.")
            return
        if not configured_admin_id():
            self._answer_callback(callback_id, "Сначала владелец должен назначить администратора.")
            return
        if data.startswith("admin:") and not self.is_admin(user_id):
            self._answer_callback(callback_id, "Эта кнопка доступна только администратору.")
            return
        self._answer_callback(callback_id)

        if data == "choose_market":
            self.edit_message(chat_id, message_id, "<b>Выбери стакан:</b>", market_picker_keyboard())
            return
        if data == "menu":
            self.edit_message(chat_id, message_id, "<b>Ловец мерчантов</b>\nВыбери действие:", main_keyboard(self.is_admin(user_id)))
            return
        if data == "personal:add":
            self._begin_input(chat_id, message_id, user_id, "personal")
            return
        if data == "personal:list":
            self._render_personal_list(chat_id, message_id, user_id)
            return
        if data == "cancel_input":
            self.pending_inputs.pop(str(user_id), None)
            self.edit_message(chat_id, message_id, "Добавление отменено.", back_to_menu_keyboard(self.is_admin(user_id)))
            return
        if data.startswith("personal:pick:"):
            profile_id = data.split(":", 2)[2].lower()
            merchant = next((item for item in load_user_merchants(user_id) if merchant_key(item) == profile_id), None)
            if not merchant:
                self.edit_message(chat_id, message_id, "Этой ссылки уже нет в твоём списке.", back_to_menu_keyboard(self.is_admin(user_id)))
                return
            keyboard = {"inline_keyboard": [[
                {"text": "Удалить", "callback_data": f"personal:confirm:{profile_id}"},
                {"text": "Оставить", "callback_data": "personal:list"},
            ]]}
            self.edit_message(chat_id, message_id, f"Удалить личную отслежку <b>{html.escape(merchant['nickname'])}</b>?", keyboard)
            return
        if data.startswith("personal:confirm:"):
            profile_id = data.split(":", 2)[2].lower()
            self._delete_user_merchant(user_id, profile_id)
            self.edit_message(chat_id, message_id, "Удалил отслежку из твоего личного списка.", back_to_menu_keyboard(self.is_admin(user_id)))
            return
        if data == "admin:home":
            self._render_admin_home(chat_id, message_id)
            return
        if data == "admin:add":
            self._begin_input(chat_id, message_id, user_id, "admin")
            return
        if data == "admin:delete":
            self._render_global_delete_list(chat_id, message_id)
            return
        if data == "admin:list":
            self._render_global_list(chat_id, message_id)
            return
        if data.startswith("admin:pick:"):
            key = data.split(":", 2)[2]
            merchant = self._global_by_key(key)
            if not merchant:
                self.edit_message(chat_id, message_id, "Этого мерчанта уже нет в общем списке.", back_to_menu_keyboard(True))
                return
            keyboard = {"inline_keyboard": [[
                {"text": "🗑 Удалить", "callback_data": f"admin:confirm:{key}"},
                {"text": "Отмена", "callback_data": "admin:delete"},
            ]]}
            self.edit_message(chat_id, message_id, f"Удалить <b>👑 {html.escape(merchant['nickname'])}</b> из общего списка для всех пользователей?", keyboard)
            return
        if data.startswith("admin:confirm:"):
            key = data.split(":", 2)[2]
            self._delete_global_merchant(key)
            self.edit_message(chat_id, message_id, "Удалил мерчанта из общего списка. Личные отслежки пользователей не затронуты.", back_to_menu_keyboard(True))
            return
        if data.startswith(("market:", "refresh:")):
            force = data.startswith("refresh:")
            market = data.split(":", 1)[1]
            if market not in MARKETS:
                self.edit_message(chat_id, message_id, "Доступны только USDT/USD и USDT/TJS.", market_picker_keyboard())
                return
            self.edit_message(chat_id, message_id, f"⏳ Проверяю <b>{html.escape(market)}</b> по объявлениям Bybit…")
            try:
                merchants, complete = self.scan(user_id, market, force=force)
                text = format_results(market, merchants, complete)
            except BotError as exc:
                text = f"<b>Не удалось проверить {html.escape(market)}.</b>\n{html.escape(str(exc))}"
            pages = split_html_message(text)
            self.edit_message(chat_id, message_id, pages[0], results_keyboard(market))
            for page in pages[1:]:
                self.send_message(chat_id, page)

    def process_update(self, update: dict[str, Any]) -> None:
        message = update.get("message")
        if isinstance(message, dict):
            self.handle_message(message)
        callback = update.get("callback_query")
        if isinstance(callback, dict):
            try:
                self.handle_callback(callback)
            except BotError as exc:
                print(f"Ошибка обработки кнопки: {exc}", file=sys.stderr)

    def run(self) -> None:
        profile = self.telegram.call("getMe")
        print(f"Бот запущен: @{profile.get('username', 'unknown')}")
        print("Оставь это окно Terminal открытым. Для остановки нажми Ctrl+C.")
        claim_code = ensure_admin_claim_code()
        if claim_code:
            print("\nПЕРВИЧНАЯ НАСТРОЙКА АДМИНА")
            print(f"Напиши боту в личку: /claimadmin {claim_code}")
            print("Не пересылай этот одноразовый код другим людям.\n")
        while True:
            try:
                updates = self.telegram.call(
                    "getUpdates",
                    {"offset": self.offset, "timeout": 50, "allowed_updates": ["message", "callback_query"]},
                    timeout=65,
                ) or []
                for update in updates:
                    self.offset = max(self.offset, int(update.get("update_id", 0)) + 1)
                    try:
                        self.process_update(update)
                    except BotError as exc:
                        print(f"Ошибка Telegram: {exc}", file=sys.stderr)
            except KeyboardInterrupt:
                print("\nБот остановлен.")
                return
            except BotError as exc:
                print(f"Ошибка соединения: {exc}", file=sys.stderr)
                time.sleep(4)
            except Exception as exc:  # keep the long-poll process alive after unexpected errors
                print(f"Непредвиденная ошибка: {exc}", file=sys.stderr)
                time.sleep(4)


def main() -> int:
    try:
        token = load_token()
        MerchantBot(token).run()
        return 0
    except BotError as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nБот остановлен.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())

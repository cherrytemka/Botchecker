#!/bin/bash
cd "$(dirname "$0")"
PYTHON=""
for version in 3.14 3.13 3.12 3.11 3.10 3.9; do
  candidate="/Library/Frameworks/Python.framework/Versions/$version/bin/python3"
  if [ -x "$candidate" ]; then PYTHON="$candidate"; break; fi
done
if [ -z "$PYTHON" ]; then PYTHON="$(command -v python3 2>/dev/null || true)"; fi
if [ -z "$PYTHON" ]; then echo "Не найден Python 3."; exit 1; fi
"$PYTHON" mac_autostart.py remove
status=$?
read -r -p "Нажми Enter, чтобы закрыть окно Terminal..." _
exit "$status"

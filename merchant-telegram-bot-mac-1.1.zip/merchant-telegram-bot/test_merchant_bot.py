import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import merchant_bot


class MerchantBotTests(unittest.TestCase):
    def test_backup_has_profiles_and_market_menu_is_limited(self):
        merchants = merchant_bot.load_merchants()
        self.assertEqual(len(merchants), 16)
        self.assertEqual(set(merchant_bot.MARKETS), {"USDT/USD", "USDT/TJS"})
        self.assertTrue(all(item["profileId"].startswith("s") for item in merchants))
        self.assertTrue(all(item["adminAdded"] for item in merchant_bot.load_global_merchants()))

    def test_crown_only_marks_global_merchants(self):
        common = {
            "profileId": "s" + "a" * 32, "uid": "", "nickname": "Common", "source": "",
            "adminAdded": True, "onlineAds": 1, "buyFromMerchantAds": 1, "sellToMerchantAds": 0,
        }
        personal = {
            "profileId": "s" + "b" * 32, "uid": "", "nickname": "Private", "source": "",
            "adminAdded": False, "onlineAds": 1, "buyFromMerchantAds": 0, "sellToMerchantAds": 1,
        }
        text = merchant_bot.format_results("USDT/USD", [common, personal], True)
        self.assertIn("👑 Common", text)
        self.assertIn(">Private</a>", text)
        self.assertNotIn("👑 Private", text)
        normal_buttons = str(merchant_bot.main_keyboard(False))
        admin_buttons = str(merchant_bot.main_keyboard(True))
        self.assertNotIn("admin:home", normal_buttons)
        self.assertIn("admin:home", admin_buttons)

    def test_scan_includes_only_matching_online_ads_for_selected_book(self):
        merchants = [
            {"profileId": "s" + "a" * 32, "uid": "", "nickname": "Trader A", "source": ""},
            {"profileId": "s" + "b" * 32, "uid": "", "nickname": "Trader B", "source": ""},
        ]
        data = {
            "0": [{"id": "ad-a-buy", "userMaskId": merchants[0]["profileId"], "isOnline": True}],
            "1": [
                {"id": "ad-a-sell", "userMaskId": merchants[0]["profileId"], "isOnline": "1"},
                {"id": "ad-b-offline", "userMaskId": merchants[1]["profileId"], "isOnline": False},
            ],
        }
        requested = []

        def get_ads(payload):
            requested.append(payload)
            return {"count": 1, "items": data[payload["side"]] if payload["page"] == "1" else []}

        online, complete = merchant_bot.scan_market(
            merchants, "USDT/USD", get_ads, max_pages=2, page_size=100, request_delay=0
        )
        self.assertTrue(complete)
        self.assertEqual([item["nickname"] for item in online], ["Trader A"])
        self.assertEqual(online[0]["onlineAds"], 2)
        self.assertEqual(online[0]["buyFromMerchantAds"], 1)
        self.assertEqual(online[0]["sellToMerchantAds"], 1)
        self.assertTrue(all(item["tokenId"] == "USDT" and item["currencyId"] == "USD" for item in requested))

    def test_profile_link_opens_selected_market(self):
        merchant = {"profileId": "s" + "c" * 32, "source": "https://www.bybit.com/ru-RU/p2p/profile/" + "s" + "c" * 32}
        url = merchant_bot.profile_url_for_market(merchant, "USDT/TJS")
        self.assertIn("tokenId=USDT", url)
        self.assertIn("currencyId=TJS", url)
        with self.assertRaises(merchant_bot.BotError):
            merchant_bot.profile_url_for_market(merchant, "USDT/GEL")

    def test_profile_link_validation_rejects_non_bybit_and_extracts_profile_id(self):
        profile_id = "s" + "d" * 32
        link = f"https://www.bybit.com/ru-RU/p2p/profile/{profile_id}?ref=telegram"
        self.assertEqual(merchant_bot.parse_profile_link(link), profile_id)
        with self.assertRaises(merchant_bot.BotError):
            merchant_bot.parse_profile_link("https://example.com/p2p/profile/" + profile_id)

    def test_private_merchant_is_isolated_to_its_telegram_user(self):
        private_id = "s" + "e" * 32
        with TemporaryDirectory() as directory:
            data_path = Path(directory) / "bot_data.json"
            with patch.object(merchant_bot, "DATA_PATH", data_path):
                bot = object.__new__(merchant_bot.MerchantBot)
                bot.cache = {}
                result = bot._add_user_merchant(111, private_id)
                self.assertIn("твой личный список", result)
                self.assertEqual([m["profileId"] for m in merchant_bot.load_user_merchants(111)], [private_id])
                self.assertEqual(merchant_bot.load_user_merchants(222), [])

    def test_admin_additions_are_crowned_and_delete_is_global(self):
        admin_id = "s" + "f" * 32
        with TemporaryDirectory() as directory:
            data_path = Path(directory) / "bot_data.json"
            with patch.object(merchant_bot, "DATA_PATH", data_path):
                bot = object.__new__(merchant_bot.MerchantBot)
                bot.cache = {}
                bot._add_global_merchant(admin_id)
                added = next(m for m in merchant_bot.load_global_merchants() if m["profileId"] == admin_id)
                self.assertTrue(added["adminAdded"])
                bot._delete_global_merchant(admin_id)
                self.assertFalse(any(m["profileId"] == admin_id for m in merchant_bot.load_global_merchants()))

    def test_admin_can_hide_a_backup_merchant_and_restore_it(self):
        profile_id = merchant_bot.load_merchants()[0]["profileId"]
        with TemporaryDirectory() as directory:
            data_path = Path(directory) / "bot_data.json"
            with patch.object(merchant_bot, "DATA_PATH", data_path):
                bot = object.__new__(merchant_bot.MerchantBot)
                bot.cache = {}
                bot._delete_global_merchant(profile_id)
                self.assertFalse(any(m["profileId"] == profile_id for m in merchant_bot.load_global_merchants()))
                bot._add_global_merchant(profile_id)
                self.assertTrue(any(m["profileId"] == profile_id for m in merchant_bot.load_global_merchants()))

    def test_only_one_user_can_claim_admin_with_local_code(self):
        class FakeTelegram:
            def __init__(self):
                self.calls = []

            def call(self, method, payload=None, *, timeout=30):
                self.calls.append((method, payload))

        with TemporaryDirectory() as directory, patch.dict("os.environ", {"BOT_ADMIN_ID": ""}):
            config_path = Path(directory) / "bot_config.json"
            with patch.object(merchant_bot, "CONFIG_PATH", config_path):
                merchant_bot.save_bot_config({"token": "local-test-token", "admin_claim_code": "private-code"})
                bot = merchant_bot.MerchantBot("not-used")
                fake_telegram = FakeTelegram()
                bot.telegram = fake_telegram
                claim_message = {
                    "chat": {"id": 111, "type": "private"},
                    "from": {"id": 111},
                    "text": "/claimadmin private-code",
                }
                bot.handle_message(claim_message)
                config = merchant_bot.load_bot_config()
                self.assertEqual(config["admin_id"], "111")
                self.assertNotIn("admin_claim_code", config)
                self.assertTrue(bot.is_admin(111))
                self.assertFalse(bot.is_admin(222))

                claim_message["chat"]["id"] = 222
                claim_message["from"]["id"] = 222
                bot.handle_message(claim_message)
                self.assertEqual(merchant_bot.load_bot_config()["admin_id"], "111")


if __name__ == "__main__":
    unittest.main()

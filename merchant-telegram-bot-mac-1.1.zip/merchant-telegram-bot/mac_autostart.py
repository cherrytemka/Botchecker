#!/usr/bin/env python3
"""Install or remove a per-user macOS LaunchAgent for the Telegram bot."""

from __future__ import annotations

import os
import plistlib
import shutil
import subprocess
import sys
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "bot_config.json"
AGENT_LABEL = "com.merchantcatcher.telegrambot"
AGENT_DIR = Path.home() / "Library" / "LaunchAgents"
PLIST_PATH = AGENT_DIR / f"{AGENT_LABEL}.plist"


def find_python() -> str:
    for version in ("3.14", "3.13", "3.12", "3.11", "3.10", "3.9"):
        candidate = Path(f"/Library/Frameworks/Python.framework/Versions/{version}/bin/python3")
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return shutil.which("python3") or sys.executable


def run_launchctl(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["launchctl", *args], text=True, capture_output=True, check=False)


def install() -> int:
    if sys.platform != "darwin":
        print("Автозапуск работает только в macOS.", file=sys.stderr)
        return 1
    if not CONFIG_PATH.exists():
        print("Сначала один раз запусти Start.command и сохрани токен бота.", file=sys.stderr)
        return 1
    python = find_python()
    AGENT_DIR.mkdir(parents=True, exist_ok=True)
    agent = {
        "Label": AGENT_LABEL,
        "ProgramArguments": [python, str(BASE_DIR / "merchant_bot.py")],
        "WorkingDirectory": str(BASE_DIR),
        "RunAtLoad": True,
        "KeepAlive": True,
        "ThrottleInterval": 10,
        "StandardOutPath": str(BASE_DIR / "bot.log"),
        "StandardErrorPath": str(BASE_DIR / "bot.log"),
    }
    with PLIST_PATH.open("wb") as file:
        plistlib.dump(agent, file)

    domain = f"gui/{os.getuid()}"
    run_launchctl("bootout", domain, str(PLIST_PATH))
    result = run_launchctl("bootstrap", domain, str(PLIST_PATH))
    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "launchctl не принял настройку."
        print(f"Не удалось включить автозапуск: {message}", file=sys.stderr)
        return result.returncode or 1
    run_launchctl("enable", f"{domain}/{AGENT_LABEL}")
    print("Автозапуск установлен. Бот работает в фоне и стартует при входе в Mac.")
    print(f"Лог работы: {BASE_DIR / 'bot.log'}")
    print("Если Mac уснёт или потеряет интернет, бот временно перестанет отвечать.")
    return 0


def remove() -> int:
    if sys.platform != "darwin":
        print("Автозапуск работает только в macOS.", file=sys.stderr)
        return 1
    domain = f"gui/{os.getuid()}"
    run_launchctl("bootout", domain, str(PLIST_PATH))
    try:
        PLIST_PATH.unlink()
    except FileNotFoundError:
        pass
    print("Автозапуск удалён. Конфигурация с токеном и список мерчантов не удалены.")
    return 0


def main() -> int:
    action = sys.argv[1:] or ["install"]
    if action == ["install"]:
        return install()
    if action == ["remove"]:
        return remove()
    print("Использование: python3 mac_autostart.py [install|remove]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
